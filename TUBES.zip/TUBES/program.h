#ifndef program_h
#define program_h

// FUNCTION SETIAP HOMEPAGE
int main_antrian();				//FILE : homepage.cpp

#endif
